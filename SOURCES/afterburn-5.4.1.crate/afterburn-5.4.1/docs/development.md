---
nav_order: 4
has_children: true
has_toc: false
---

# Development

## Integrating Afterburn into a distribution

See [Integrating Afterburn into a distribution](development/distro.md).
